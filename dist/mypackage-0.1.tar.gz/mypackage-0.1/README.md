# mypackage
This library is a class session assignment that illustrates how to publish a packgage in python. The file has comments describing its usefulness in sorting numbers in a decseding order.